/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import algorithm.EllipticCurveAlgorithm;
import algorithm.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author Dell
 */
public class userregaction extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
       String uname=request.getParameter("uname");
    String pass=request.getParameter("pass");
    String gen=request.getParameter("g1");
    int age=Integer.parseInt(request.getParameter("age"));
    String email=request.getParameter("email");
    String mono=request.getParameter("mono");
    String addr=request.getParameter("addr");
    EllipticCurveAlgorithm ECC = new EllipticCurveAlgorithm();
    byte[] resultByte;
    byte[] resultByte1;
    int uid=0;
    try
    {
        Connection con=dbcon.DbConnection.getConnection();
        Statement st=con.createStatement();
        Statement stq=con.createStatement();
        ResultSet rsq=stq.executeQuery("select max(uid) from user");
        if(rsq.next())
        {
            int id=rsq.getInt(1);
            if(id==0)
            {
                uid=1;
            }else
            {
                uid=id+1;
            }
        }
        Point publicKey = ECC.generatePublicKey(uid);
        String publickey1=publicKey.toString();
        String privatekey=uid+"";
        String contextpath=getServletContext().getRealPath("/");
            String pathes=contextpath+"\\"+uname+"\\";
            System.out.println("Pathes=="+pathes);
            String path=pathes;
             System.out.println("Path=="+path);
             File folder = new File(pathes);
             folder.mkdir();
             String folder_location = folder.toString() + "\\";
             String filename = "public";
            File file = new File(folder_location + filename.toString() + ".key");
                FileWriter out1 = new FileWriter(file);
                if (!file.exists()) {
                file.createNewFile();
            }
                out1.write(publickey1);
                out1.flush();
                out1.close();
            
                String filename1 = "secret";
            File file1 = new File(folder_location + filename1.toString() + ".key");
            //File file1= new File(path1);
             if (!file.exists()) {
                file1.createNewFile();
            }
                
            FileWriter out2 = new FileWriter(file1);
                out2.write(privatekey);
                out2.flush();
                out2.close();
            
           String filePath=folder_location+filename.toString() + ".key";
           FileReader fileReader = null;
            try {
            fileReader = new FileReader(filePath);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
             Point pub = new Point();
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        try {
            String key = bufferedReader.readLine();
            String[] str = key.split(" ");
            pub.setX(Long.parseLong(str[0]));
            pub.setY(Long.parseLong(str[1]));
            System.out.println("Public key : " + pub);
            bufferedReader.close();
        } catch (Exception ex1) {
           ex1.printStackTrace();
        }
        byte[] bytes=uname.getBytes();
        resultByte = ECC.encrypt(bytes, pub);
        String encuname=DatatypeConverter.printHexBinary(resultByte);
        String filename2 = uname;
            File file3 = new File(folder_location + filename2.toString() + ".enc");
             if(!file3.exists())
            {
                file3.createNewFile();
            }
            
                FileWriter out3 = new FileWriter(file3);
                out3.write(encuname);
                out3.flush();
                out3.close();
            
        byte[] bytes1=pass.getBytes();
        resultByte1 = ECC.encrypt(bytes1, pub);
        String encpass=DatatypeConverter.printHexBinary(resultByte1);
        String filename3 = "pass";
            File file4 = new File(folder_location + filename3.toString() + ".enc");
            
             if(!file4.exists())
            {
                file4.createNewFile();
            }
            FileWriter out4 = new FileWriter(file4);
                out4.write(encpass);
                out4.flush();
                out4.close();
            
        
        ResultSet rs=st.executeQuery("select * from user where uname='"+encuname+"' or email='"+email+"'");
        if(rs.next())
        {
            response.sendRedirect("ureg.jsp?msg=uname_already_exist");
        }else
        {
            PreparedStatement pstm=con.prepareStatement("insert into user(uname,pass,email,mono,age,gen,addr,sts) values(?,?,?,?,?,?,?,?)");
            pstm.setString(1, encuname);
            pstm.setString(2, encpass);
            pstm.setString(3, email);
            pstm.setString(4, mono);
            pstm.setInt(5, age);
            pstm.setString(6,gen);
            pstm.setString(7, addr);
            pstm.setString(8, "No");
            int x=pstm.executeUpdate();
            if(x>0)
            {
                response.sendRedirect("ulogin.jsp?msg=success");
            }else
            {
                response.sendRedirect("ureg.jsp?msg1=error");
            }
        }
        
    }catch(Exception e)
    {
        e.printStackTrace();
    }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(userregaction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(userregaction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
