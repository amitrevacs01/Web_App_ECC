/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import algorithm.EllipticCurveAlgorithm;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author Dell
 */
public class userloginaction extends HttpServlet {
byte[] resultByte;
    byte[] resultByte1;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession ss=request.getSession();
        try
        {
            String uname=request.getParameter("uname");
            String pass=request.getParameter("pass");
            String contextpath=getServletContext().getRealPath("/");
             String pathes=contextpath+"\\"+uname+"\\";
            String filename1 = "secret";
            //File file1 = new File(
            String filePath = pathes + filename1.toString() + ".key";
            System.out.println("Secreat key path=="+filePath);
        FileReader fileReader = null;
        FileReader fileReader1 = null;
        try {
            fileReader = new FileReader(filePath);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        long pri = 0;
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String text ="";
        String text1="";
        try {
            String key = bufferedReader.readLine();
            System.out.println("Key=="+key);
            pri = Long.parseLong(key);
            bufferedReader.close();
            fileReader.close();
            String filename = uname;
            //File file1 = new File(
            String filePath1 = pathes + filename.toString() + ".enc";
            System.out.println("Encrypted file path="+filePath1);
            fileReader = new FileReader(filePath1);
            bufferedReader = new BufferedReader(fileReader);
            text = bufferedReader.readLine();
            System.out.println("Encrypted data="+text);
            bufferedReader.close();
            fileReader.close();
           
            String filenamep = "pass";
            //File file1 = new File(
            String filePathp = pathes + filenamep.toString() + ".enc";
            System.out.println("Encrypted password file path="+filePathp);
            fileReader1 = new FileReader(filePathp);
            bufferedReader = new BufferedReader(fileReader1);
            text1 = bufferedReader.readLine();
            bufferedReader.close();
            fileReader1.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
         byte[] bytes = DatatypeConverter.parseHexBinary(text);
         byte[] bytes1 = DatatypeConverter.parseHexBinary(text1);
         EllipticCurveAlgorithm ECC = new EllipticCurveAlgorithm();
        resultByte = ECC.decrypt(bytes, pri);
        resultByte1 = ECC.decrypt(bytes1, pri);
        
        String un=new String(resultByte);
        String pa=new String(resultByte1);
            System.out.println("Decrypted uname="+un);
            System.out.println("Decrypted passworde="+pa);
            if(uname.equals(un))
            {
                if(pass.equals(pa))
                {
                    Connection con=dbcon.DbConnection.getConnection();
                    Statement st=con.createStatement();
                    ResultSet rs=st.executeQuery("select * from user where uname='"+text+"' and sts='Yes'");
                    if(rs.next())
                    {
                        ss.setAttribute("uname", un);
                        response.sendRedirect("uhome.jsp?msg=success");
                    }else
                    {
                         response.sendRedirect("ulogin.jsp?msg=Account_not_Activated");
                    }
                }else
                {
                    response.sendRedirect("ulogin.jsp?ms1=invaild_password");
                }
            }else
            {
                response.sendRedirect("ulogin.jsp?ms=invaild_uname");
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
